package Test;

public class Mail_connectivity {
	
	public Mail_connectivity() {
		System.out.println("poda");
	}

	public static void main(String[] args) {
		Mail_connectivity mail = new Mail_connectivity();
		//EmailUtils emailutils = new EmailUtils();

	}

}
