package Test;

public class Overloading {
	
	    
	    public void m1(int a){
	        System.out.println(a);
			//return a;
	    }
	    public static void main(String args []){
	        Overloading over = new Overloading();
	        over.m1(25);
	        
	        //System.out.print(over.m1(25));
	        
	    }
	}


